package com.example.slimfit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    EditText nome, senha;
    Pessoa u;
    ArrayList<Pessoa> lista = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        nome = findViewById(R.id.nomec);
        senha = findViewById(R.id.senhac);
        Pessoa p1 = new Pessoa("João","123");
        Pessoa p2 = new Pessoa("","");
        lista.add(p1);
        lista.add(p2);
    }
    public void logar(View v){
        String n = nome.getText().toString();
        String s = senha.getText().toString();
        String mensagem = "Bem vindo";
        for(Pessoa p:lista){
            if(p.getNome().equals(n)) {
                if (p.getSenha().equals(s)) {
                    mensagem = "bem vindo";
                    Intent i = new Intent(this, Dados.class);
                    startActivity(i);
                    u = p;
                    Dados.u = u;
                    break;
                } else {
                    mensagem = "Senha incorreta";
                }
            }
            else{
                mensagem = "O usuario não existe";
            }
        }
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show();
    }
    public void cadastrar(View v){
        Intent i = new Intent(this, cadastro.class);
        startActivity(i);
        cadastro.lista = lista;
    }
}