package com.example.slimfit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Dados extends AppCompatActivity {
    static Pessoa u;
    EditText idade, peso, alt;
    TextView pessoa;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dados);
        getSupportActionBar().hide();
        idade = findViewById(R.id.idade);
        peso = findViewById(R.id.peso);
        alt = findViewById(R.id.alt);
        pessoa = findViewById(R.id.pessoa);
        pessoa.setText(u.getNome());
    }
    public void iniciar(View v){

        int i = Integer.parseInt(idade.getText().toString());
        float p = Float.parseFloat(peso.getText().toString());
        float a = Float.parseFloat(alt.getText().toString());
        u.setAltura(a);
        u.setIdade(i);
        u.setPeso(p);
        Intent y = new Intent(this, Tela_inicial.class);
        startActivity(y);
    }
}