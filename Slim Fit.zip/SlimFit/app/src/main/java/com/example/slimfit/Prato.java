package com.example.slimfit;

public class Prato {
    String nomep, complemento, hora;
    public Prato(String nomep, String hora) {
        this.nomep = nomep;
        this.hora = hora;
    }
    public Prato(String nomep, String hora, String complemento) {
        this.nomep = nomep;
        this.hora = hora;
        this.complemento = complemento;
    }

    public String getNomep() {
        return nomep;
    }

    public void setNomep(String nomep) {
        this.nomep = nomep;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }
}
