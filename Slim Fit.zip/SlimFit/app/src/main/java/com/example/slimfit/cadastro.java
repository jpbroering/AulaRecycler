package com.example.slimfit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;

public class cadastro extends AppCompatActivity {
EditText nomec,senhac,confsenha;
static ArrayList<Pessoa> lista;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        getSupportActionBar().hide();
        nomec = findViewById(R.id.nomec);
        senhac = findViewById(R.id.senhac);
        confsenha = findViewById(R.id.confsenha);
    }
    public void cadastrar(View v){
        String n = nomec.getText().toString();
        String s = senhac.getText().toString();
        String c = confsenha.getText().toString();
        if(s.equals(c)){
            Pessoa p = new Pessoa(n,s);
            lista.add(p);
            super.onBackPressed();
        }
    }
    public void voltar(View v){
        super.onBackPressed();
    }
}