package com.example.slimfit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adaptadorv extends RecyclerView.Adapter<Adaptadorv.MyViewHolder> {
    Context context;
    static ArrayList<Prato> lista;
    OnItemClickListener listener;
    int layout;

    public Adaptadorv(Context context, ArrayList<Prato> lista, OnItemClickListener listener, int layout) {
        this.context = context;
        this.lista = lista;
        this.listener = listener;
        this.layout = layout;
    }

    @NonNull
    @Override
    public Adaptadorv.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(layout, parent,false);
        return new Adaptadorv.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptadorv.MyViewHolder holder, int position) {
        System.out.println(lista);
        Prato p = lista.get(position);
        holder.nome.setText(p.getNomep());
        holder.hora.setText(p.getHora());
        holder.comp.setText(p.getComplemento());
        holder.itemView.setOnClickListener(view ->{
            listener.onItemClick(p);
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public interface OnItemClickListener {
        void onItemClick(Prato p);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nome, hora, comp;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nome = itemView.findViewById(R.id.nome);
            hora = itemView.findViewById(R.id.categoria);
            comp = itemView.findViewById(R.id.preco);
        }
    }
}
