package com.example.aularecycler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;

public class Cadastrar extends AppCompatActivity {
    static ArrayList<Produto> listaProdutos;
    EditText nomec,catc,valorc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);
        getSupportActionBar().hide();
        nomec = findViewById(R.id.nomec);
        catc = findViewById(R.id.catc);
        valorc = findViewById(R.id.valorc);

    }
    public void cadastra(View v){
        String n = nomec.getText().toString();
        String c = catc.getText().toString();
        Float vc = Float.parseFloat(valorc.getText().toString());
        Produto p1 = new Produto(n,c,vc);
        listaProdutos.add(p1);
    }
    public void voltar(View v){
        super.onBackPressed();
    }
}